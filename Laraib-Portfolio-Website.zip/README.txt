# Laraib Aslam Portfolio

A responsive portfolio website built with HTML, CSS and JavaScript.

## Before publishing
1. Open `index.html`.
2. Replace `YOUR-EMAIL@example.com` with your real email.
3. Replace the LinkedIn and GitHub links with your actual profiles.
4. Add screenshots/images of your real projects if available.

## GitHub Pages
Upload these three files (`index.html`, `style.css`, `script.js`) to a GitHub repository.
Then go to Settings -> Pages -> Deploy from branch -> choose `main` and `/root`.
Your portfolio will receive a free `github.io` web address.
